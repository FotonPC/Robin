import robinlexer,robinerror,robinanaliz,robintypes,robincalc
while True:
    print(robincalc.calc(input()))
    #except: print('Error')
